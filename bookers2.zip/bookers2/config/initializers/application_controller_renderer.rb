# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '4a027daf8d19c6a30737448a3df30992b0bd0f187b5c93a36273d10ec938f03d1ba01019099dc499c6d469a19eac8ac284baaf4f42fdc648f4beececbd1b2c2c'